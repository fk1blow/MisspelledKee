(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var Cop2Class;

Cop2Class = (function() {
  function Cop2Class() {}

  return Cop2Class;

})();

console.log('Cop2Class');


},{}],2:[function(require,module,exports){
var CopClass;

CopClass = (function() {
  function CopClass() {}

  return CopClass;

})();

console.log('CopClass');


},{}],3:[function(require,module,exports){
var FuckingClass2, copy, copy2;

copy = require('./copy.coffee');

copy2 = require('./copy\ copy.coffee');

FuckingClass2 = (function() {
  function FuckingClass2() {}

  return FuckingClass2;

})();

console.log('FuckingClass2');


},{"./copy copy.coffee":1,"./copy.coffee":2}]},{},[3])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlcyI6WyIvVXNlcnMvRHJhZ29zL1BsYXlncm91bmQvTWlzc3BlbGxlZEtlZS9ub2RlX21vZHVsZXMvZ3VscC1icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCIvVXNlcnMvRHJhZ29zL1BsYXlncm91bmQvTWlzc3BlbGxlZEtlZS9hcHAvc2NyaXB0cy9jb3B5IGNvcHkuY29mZmVlIiwiL1VzZXJzL0RyYWdvcy9QbGF5Z3JvdW5kL01pc3NwZWxsZWRLZWUvYXBwL3NjcmlwdHMvY29weS5jb2ZmZWUiLCIvVXNlcnMvRHJhZ29zL1BsYXlncm91bmQvTWlzc3BlbGxlZEtlZS9hcHAvc2NyaXB0cy90ZXN0LmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQ0FBLElBQUEsU0FBQTs7QUFBQTt5QkFBQTs7bUJBQUE7O0lBQUEsQ0FBQTs7QUFBQSxPQUVPLENBQUMsR0FBUixDQUFZLFdBQVosQ0FGQSxDQUFBOzs7O0FDQUEsSUFBQSxRQUFBOztBQUFBO3dCQUFBOztrQkFBQTs7SUFBQSxDQUFBOztBQUFBLE9BRU8sQ0FBQyxHQUFSLENBQVksVUFBWixDQUZBLENBQUE7Ozs7QUNBQSxJQUFBLDBCQUFBOztBQUFBLElBQUEsR0FBTyxPQUFBLENBQVEsZUFBUixDQUFQLENBQUE7O0FBQUEsS0FDQSxHQUFRLE9BQUEsQ0FBUSxxQkFBUixDQURSLENBQUE7O0FBQUE7NkJBR0E7O3VCQUFBOztJQUhBLENBQUE7O0FBQUEsT0FLTyxDQUFDLEdBQVIsQ0FBWSxlQUFaLENBTEEsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKX12YXIgZj1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwoZi5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxmLGYuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiY2xhc3MgQ29wMkNsYXNzXG5cbmNvbnNvbGUubG9nICdDb3AyQ2xhc3MnXG4iLCJjbGFzcyBDb3BDbGFzc1xuXG5jb25zb2xlLmxvZyAnQ29wQ2xhc3MnXG4iLCJjb3B5ID0gcmVxdWlyZSAnLi9jb3B5LmNvZmZlZSdcbmNvcHkyID0gcmVxdWlyZSAnLi9jb3B5XFwgY29weS5jb2ZmZWUnXG5cbmNsYXNzIEZ1Y2tpbmdDbGFzczJcblxuY29uc29sZS5sb2cgJ0Z1Y2tpbmdDbGFzczInXG4iXX0=
